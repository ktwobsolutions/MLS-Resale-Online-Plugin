<?php
// Hook to add the settings page to the WordPress admin menu.
add_action('admin_menu', 'mls_plugin_add_admin_menu');

// Function to add the settings page.
function mls_plugin_add_admin_menu() {
    add_menu_page(
        'MLS Plugin Settings', // Page title
        'MLS Plugin',          // Menu title
        'manage_options',      // Capability required to access this menu
        'mls_plugin_settings', // Menu slug
        'mls_plugin_settings_page', // Function to display the page content
        'dashicons-admin-generic', // Icon for the menu
        20                     // Position on the menu
    );
}

// Function to display the settings page content.
/*
function mls_plugin_settings_page() {
    ?>
    <div class="wrap mls-custom-admin-style">
        <h1>MLS Plugin Settings</h1>
        <?php if (isset($_GET['settings-updated']) && $_GET['settings-updated']): ?>
            <div id="setting-error-settings_updated" class="updated notice is-dismissible">
                <p><strong>Settings saved successfully.</strong></p>
            </div>
        <?php endif; ?>

        <ul class="nav-tab-wrapper mls-admin-navtab" data-tabgroup="first-tab-group">
            <li><a href="#tab1" class="nav-tab nav-tab-active">Connection with Resales Online</a></li>
            <li><a href="#tab2" class="nav-tab">Styles</a></li>
            <li><a href="#tab3" class="nav-tab">Integration with Map</a></li>
            <li><a href="#tab4" class="nav-tab">Lead Form</a></li>
            <li><a href="#tab6" class="nav-tab">Language</a></li>
        </ul>

<section id="first-tab-group" class="tabgroup">        
        <form method="post" action="options.php">
    <?php
    settings_fields('mls_plugin_settings_group');
    do_settings_sections('mls_plugin');
    ?>
    

    <div id="tab1" class="tab-content">
		<table class="form-table">
        <!-- Existing API Key field -->
        <tr valign="top">
            <th scope="row">API Key</th>
            <td><input type="text" name="mls_plugin_api_key" value="<?php echo esc_attr(get_option('mls_plugin_api_key')); ?>" /></td>
        </tr>

        <!-- New Client ID field -->
        <tr valign="top">
            <th scope="row">Client ID</th>
            <td><input type="text" name="mls_plugin_client_id" value="<?php echo esc_attr(get_option('mls_plugin_client_id')); ?>" /></td>
        </tr>

        <!-- New Default Filter ID Sales field -->
        <tr valign="top">
            <th scope="row">Default Filter ID Sales</th>
            <td><input type="text" name="mls_plugin_filter_id_sales" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_sales')); ?>" /></td>
        </tr>

        <!-- New Default Filter ID Short Rentals field -->
        <tr valign="top">
            <th scope="row">Default Filter ID Short Rentals</th>
            <td><input type="text" name="mls_plugin_filter_id_short_rentals" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_short_rentals')); ?>" /></td>
        </tr>

        <!-- New Default Filter ID Long Rentals field -->
        <tr valign="top">
            <th scope="row">Default Filter ID Long Rentals</th>
            <td><input type="text" name="mls_plugin_filter_id_long_rentals" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_long_rentals')); ?>" /></td>
        </tr>

        <!-- New Default Filter ID Features field -->
        <tr valign="top">
            <th scope="row">Default Filter ID Features</th>
            <td><input type="text" name="mls_plugin_filter_id_features" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_features')); ?>" /></td>
        </tr>
		
		<!-- Include Only Property Types on Search field -->
        <tr valign="top">
            <th scope="row">Include Only Property Types on Search</th>
            <td><?php mls_plugin_property_type_filter_callback(); ?> </td>
        </tr>
			</table>
        </div>
    <div id="tab2" class="tab-content">
        <table>
     <!-- New Color Fields -->
     <tr valign="top"> <h2>MLS Plugin Colour Setting</h2>  </tr>
    <tr valign="top">
        <th scope="row">Default Color</th>
        <td><input type="text" class="mls-color-field" name="mls_plugin_default_color" value="<?php echo esc_attr(get_option('mls_plugin_default_color', '#5c727d')); ?>" /></td>
    </tr>
    <tr valign="top">
        <th scope="row">Blue Color</th>
        <td><input type="text" class="mls-color-field" name="mls_plugin_blue_color" value="<?php echo esc_attr(get_option('mls_plugin_blue_color', '#0073e1')); ?>" /></td>
    </tr>
    <tr valign="top">
        <th scope="row">Black Color</th>
        <td><input type="text" class="mls-color-field" name="mls_plugin_black_color" value="<?php echo esc_attr(get_option('mls_plugin_black_color', '#222')); ?>" /></td>
    </tr>
    <tr valign="top">
        <th scope="row">Green Color</th>
        <td><input type="text" class="mls-color-field" name="mls_plugin_green_color" value="<?php echo esc_attr(get_option('mls_plugin_green_color', '#69c17d')); ?>" /></td>
    </tr>
</table>
    </div>
    <div id="tab3" class="tab-content">
    <table>
 <!-- New Color Fields -->
 <tr valign="top"> <h2>MLS Setting3</h2>  </tr>


</table>
</div>
    <div id="tab4" class="tab-content">
			<table>
         <!-- New Color Fields -->
         <tr valign="top"> <h2>MLS Setting4</h2>  </tr>
        
        
  </table>
        </div>
    <div id="tab5" class="tab-content">
    <table>
 <!-- New Color Fields -->
 <tr valign="top"> <h2>MLS Setting5</h2>  </tr>


</table>
</div>
    <div id="tab6" class="tab-content">
    <table>
 <!-- New Color Fields -->
 <tr valign="top"> <h2>MLS Setting6</h2>  </tr>


</table>
</div>
    
    <?php submit_button(); ?>
</form>
        </section>
    </div>
    <?php
}
*/

function mls_plugin_settings_page() {
    // check user capabilities
  if ( ! current_user_can( 'manage_options' ) ) {
    return;
  }

	if (mls_plugin_is_license_valid()) {
    // Get the active tab from the $_GET parameter
    $default_tab = null;
    $tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
	
	// Process form submissions separately for each tab
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['mls_plugin_api_key'])) {
        // Process the "Connection with Resales Online" form
        update_option('mls_plugin_api_key', sanitize_text_field($_POST['mls_plugin_api_key']));
        update_option('mls_plugin_client_id', sanitize_text_field($_POST['mls_plugin_client_id']));
        update_option('mls_plugin_filter_id_sales', sanitize_text_field($_POST['mls_plugin_filter_id_sales']));
		update_option('mls_plugin_filter_id_short_rentals', sanitize_text_field($_POST['mls_plugin_filter_id_short_rentals']));
		update_option('mls_plugin_filter_id_long_rentals', sanitize_text_field($_POST['mls_plugin_filter_id_long_rentals']));
		update_option('mls_plugin_filter_id_features', sanitize_text_field($_POST['mls_plugin_filter_id_features']));
	// Handle property types submission
    if (isset($_POST['mls_plugin_property_types'])) {
        // Sanitize and encode the selected property types as JSON
//         $property_types = array_map('sanitize_text_field', $_POST['mls_plugin_property_types']);
		$property_types = array_map('stripslashes', $_POST['mls_plugin_property_types']);

        update_option('mls_plugin_property_types', $property_types);
		
		 $property_types = array_map('stripslashes', $_POST['mls_plugin_property_types']); // Decode the input

		
		
    } else {
        // Clear the stored types if no types are selected
        update_option('mls_plugin_property_types', json_encode(array()));
    }
    } elseif (isset($_POST['mls_plugin_default_color'])) { 
        // Process the "Styles" form
        update_option('mls_plugin_default_color', sanitize_text_field($_POST['mls_plugin_default_color']));
        update_option('mls_plugin_blue_color', sanitize_text_field($_POST['mls_plugin_blue_color']));
        update_option('mls_plugin_black_color', sanitize_text_field($_POST['mls_plugin_black_color']));
        update_option('mls_plugin_green_color', sanitize_text_field($_POST['mls_plugin_green_color']));
		update_option('mls_plugin_white_color', sanitize_text_field($_POST['mls_plugin_white_color']));
		update_option('mls_plugin_border_color', sanitize_text_field($_POST['mls_plugin_border_color']));
		update_option('mls_plugin_banner_search_background_color', sanitize_text_field($_POST['mls_plugin_banner_search_background_color']));
		update_option('mls_plugin_banner_search_buttonbackground_color', sanitize_text_field($_POST['mls_plugin_banner_search_buttonbackground_color']));
		update_option('mls_plugin_banner_search_text_color', sanitize_text_field($_POST['mls_plugin_banner_search_text_color']));
		update_option('mls_plugin_banner_search_button_color', sanitize_text_field($_POST['mls_plugin_banner_search_button_color']));
		update_option('mls_plugin_banner_search_buttonhoverbackground_color', sanitize_text_field($_POST['mls_plugin_banner_search_buttonhoverbackground_color']));
		
    } elseif (isset($_POST['mls_plugin_leadformtomail']) || isset($_POST['mls_plugin_available_timings'])) {
		// Sanitize and update available timings
    $selected_timings = array_map('sanitize_text_field', $_POST['mls_plugin_available_timings']);
    update_option('mls_plugin_available_timings', $selected_timings);
	update_option('mls_plugin_leadformvideohide', sanitize_text_field($_POST['mls_plugin_leadformvideohide']));
     // Process "Lead Form To mail"
    $emails = sanitize_text_field($_POST['mls_plugin_leadformtomail']);
    $emails_array = explode(',', $emails);
    $valid_emails = array_map('trim', $emails_array);
    $validated_emails = array_filter($valid_emails, 'is_email');
    update_option('mls_plugin_leadformtomail', implode(', ', $validated_emails));

    // Process "Lead Form CC mail"
    $cc_emails = sanitize_text_field($_POST['mls_plugin_leadformccmail']);
    $cc_emails_array = explode(',', $cc_emails);
    $cc_valid_emails = array_map('trim', $cc_emails_array);
    $cc_validated_emails = array_filter($cc_valid_emails, 'is_email');
    update_option('mls_plugin_leadformccmail', implode(', ', $cc_validated_emails));
		
		update_option('mls_plugin_leadformmailsubject', sanitize_text_field($_POST['mls_plugin_leadformmailsubject']));
		update_option('mls_plugin_leadformmailheadertext', sanitize_text_field($_POST['mls_plugin_leadformmailheadertext']));
		update_option('mls_plugin_leadformmailfootertext', sanitize_text_field($_POST['mls_plugin_leadformmailfootertext']));
		
		// Process "Lead Form Mail Header Logo" (Media Library Image URL)
    update_option('mls_plugin_leadformmailheaderlogo', esc_url_raw($_POST['mls_plugin_leadformmailheaderlogo']));
		
    }elseif (isset($_POST['mls_plugin_save_map_settings'])) {
    // Process the "Map Integration" form
    if (isset($_POST['mls_plugin_map_provider'])) {
        update_option('mls_plugin_map_provider', sanitize_text_field($_POST['mls_plugin_map_provider']));
    }
		
	}
    // You can add more conditions for other tabs here...
}
	
    ?>
    <!-- Our admin page content should all be inside .wrap -->
    <div class="wrap mls-custom-admin-style">
        <!-- Print the page title -->
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <!-- Here are our tabs -->
        <nav class="nav-tab-wrapper mls-admin-navtab">
            <a href="?page=mls_plugin_settings" class="nav-tab <?php if ($tab === null): ?>nav-tab-active<?php endif; ?>">Connection with Resales Online</a>
            <a href="?page=mls_plugin_settings&tab=styles" class="nav-tab <?php if ($tab === 'styles'): ?>nav-tab-active<?php endif; ?>">Styles</a>
            <a href="?page=mls_plugin_settings&tab=map_integration" class="nav-tab <?php if ($tab === 'map_integration'): ?>nav-tab-active<?php endif; ?>">Integration with Map</a>
            <a href="?page=mls_plugin_settings&tab=lead_form" class="nav-tab <?php if ($tab === 'lead_form'): ?>nav-tab-active<?php endif; ?>">Lead Form</a>
            <a href="?page=mls_plugin_settings&tab=language" class="nav-tab <?php if ($tab === 'language'): ?>nav-tab-active<?php endif; ?>">Language</a>
        </nav>

        <div class="tab-content">
        
            <?php
           

            // Render the content for each tab based on the active tab
            switch ($tab) {
                case 'styles':
                    ?>
                    <h2>MLS Plugin Colour Setting</h2>
                    <form method="post">
                    <table class="form-table">
                        <tr valign="top"> <th scope="row"><h3>General Colour Setting</h3></th></tr>
                        <tr valign="top">
                            <th scope="row">Primary Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_blue_color" value="<?php echo esc_attr(get_option('mls_plugin_blue_color', '#0073e1')); ?>" /></td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Secondary Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_green_color" value="<?php echo esc_attr(get_option('mls_plugin_green_color', '#69c17d')); ?>" /></td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Text Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_default_color" value="<?php echo esc_attr(get_option('mls_plugin_default_color', '#5c727d')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Dark Text Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_black_color" value="<?php echo esc_attr(get_option('mls_plugin_black_color', '#222')); ?>" /></td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Light Text Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_white_color" value="<?php echo esc_attr(get_option('mls_plugin_white_color', '#ffffff')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Border Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_border_color" value="<?php echo esc_attr(get_option('mls_plugin_border_color', '#e7e7e7')); ?>" /></td>
                        </tr>
						<tr valign="top"> <th scope="row"><h3>Banner Search Form Colour Setting</h3></th></tr>
						<tr valign="top">
                            <th scope="row">Form Text Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_banner_search_text_color" value="<?php echo esc_attr(get_option('mls_plugin_banner_search_text_color', '#fff')); ?>" /></td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Form Background Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_banner_search_background_color" value="<?php echo esc_attr(get_option('mls_plugin_banner_search_background_color', '#f7f7f7')); ?>" /></td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Form Button Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_banner_search_button_color" value="<?php echo esc_attr(get_option('mls_plugin_banner_search_button_color', '#fff')); ?>" /></td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Form Button Background Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_banner_search_buttonbackground_color" value="<?php echo esc_attr(get_option('mls_plugin_banner_search_buttonbackground_color', '#0073e1')); ?>" /></td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Form Button Hover Background Color</th>
                            <td><input type="text" class="mls-color-field" data-alpha-enabled="true" name="mls_plugin_banner_search_buttonhoverbackground_color" value="<?php echo esc_attr(get_option('mls_plugin_banner_search_buttonhoverbackground_color', '#69C17D')); ?>" /></td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
                    <?php
                    break;

                case 'map_integration':
    ?>
    <h2>Map Integration</h2>
    <form method="post" action="">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Select Map Provider</th>
                <td>
                    <select name="mls_plugin_map_provider" id="mls_plugin_map_provider">
                        <option value="openstreetmap" <?php selected(get_option('mls_plugin_map_provider'), 'openstreetmap'); ?>>OpenStreetMap</option>
                    </select>
                </td>
            </tr>
        </table>
        <input type="submit" name="mls_plugin_save_map_settings" value="Save Changes" class="button-primary" />
    </form>
    <?php
    break;


                case 'lead_form':
                    ?>
                    
                    <form method="post">
                    <table class="form-table easySel-style">
						<tr valign="top"> <th scope="row"><h2>Lead Form Setting</h2></th></tr>
						<tr valign="top">
    <th scope="row">Hide Tour Type field</th>
    <td>
        <input type="checkbox" name="mls_plugin_leadformvideohide" value="1" <?php checked(get_option('mls_plugin_leadformvideohide'), '1'); ?> />
        <p class="description">Check to hide the Tour Type field in Lead form. Default Value would be "Person" Store in the Submission</p>
    </td>
</tr>
						<tr valign="top">
                            <th scope="row">Available Timing</th>
                            <td>
                    <?php mls_plugin_leadform_timing(); ?>
</td>
                        </tr>
                        <tr valign="top"> <th scope="row"><h2>Email Configuration</h2></th></tr>
						<tr valign="top">
                            <th scope="row">TO Mail Address</th>
                            <td>
                    <input type="text" name="mls_plugin_leadformtomail" value="<?php echo esc_attr(get_option('mls_plugin_leadformtomail')); ?>" placeholder="Enter emails separated by commas" />
                    <p class="description">You can enter multiple email addresses separated by commas.</p>
                </td>
                        </tr>
						<tr valign="top">
                            <th scope="row">CC Mail Address</th>
                            <td>
                    <input type="text" name="mls_plugin_leadformccmail" value="<?php echo esc_attr(get_option('mls_plugin_leadformccmail')); ?>" placeholder="Enter emails separated by commas" />
                    <p class="description">You can enter multiple email addresses separated by commas.</p>
                </td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Mail Subject</th>
                            <td>
                    <input type="text" name="mls_plugin_leadformmailsubject" value="<?php echo esc_attr(get_option('mls_plugin_leadformmailsubject')); ?>"  />
                    
                </td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Mail Template Header Logo</th>
                            <td>
                    <img id="mls_plugin_leadformmailheaderlogo_preview" src="<?php echo esc_url(get_option('mls_plugin_leadformmailheaderlogo')); ?>" style="max-width: 150px; height: auto; display: <?php echo get_option('mls_plugin_leadformmailheaderlogo') ? 'block' : 'none'; ?>" />
                    <input type="hidden" id="mls_plugin_leadformmailheaderlogo" name="mls_plugin_leadformmailheaderlogo" value="<?php echo esc_attr(get_option('mls_plugin_leadformmailheaderlogo')); ?>" />
                    <button type="button" class="button" id="mls_plugin_leadformmailheaderlogo_button">Select Image</button>
                    <button type="button" class="button" id="mls_plugin_leadformmailheaderlogo_remove" style="display: <?php echo get_option('mls_plugin_leadformmailheaderlogo') ? 'inline-block' : 'none'; ?>;">Remove Image</button>
                </td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Mail Template Header Text</th>
                            <td>
                    <input type="text" name="mls_plugin_leadformmailheadertext" value="<?php echo esc_attr(get_option('mls_plugin_leadformmailheadertext')); ?>" />
                    
                </td>
                        </tr>
						<tr valign="top">
                            <th scope="row">Mail Template Footer Text</th>
                            <td>
                    <input type="text" name="mls_plugin_leadformmailfootertext" value="<?php echo esc_attr(get_option('mls_plugin_leadformmailfootertext')); ?>" />
                    
                </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
                    <?php
                    break;

                case 'language':
                    ?>
                    <h2>Language Settings</h2>
                    <!-- Add content for Language settings here -->
			<p>Language Setting will be here </p>
                    <?php
                    break;

                default:
                    ?>
                    <h2>Connection with Resales Online</h2>
			<form method="post">
                    <table class="form-table easySel-style">
                        <tr valign="top">
                            <th scope="row">API Key</th>
                            <td><input type="text" name="mls_plugin_api_key" value="<?php echo esc_attr(get_option('mls_plugin_api_key')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Client ID</th>
                            <td><input type="text" name="mls_plugin_client_id" value="<?php echo esc_attr(get_option('mls_plugin_client_id')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Default Filter ID Sales</th>
                            <td><input type="text" name="mls_plugin_filter_id_sales" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_sales')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Default Filter ID Short Rentals</th>
                            <td><input type="text" name="mls_plugin_filter_id_short_rentals" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_short_rentals')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Default Filter ID Long Rentals</th>
                            <td><input type="text" name="mls_plugin_filter_id_long_rentals" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_long_rentals')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Default Filter ID Features</th>
                            <td><input type="text" name="mls_plugin_filter_id_features" value="<?php echo esc_attr(get_option('mls_plugin_filter_id_features')); ?>" /></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Include Only Property Types on Search</th>
                            <td>
								<?php mls_plugin_property_type_filter_callback(); ?>
							</td>
                        </tr>
                    </table>
				<?php submit_button(); ?>
                </form>
                    <?php
                    break;
            }
            ?>
        
        </div>
    </div>
    <?php
	}else{ ?>
		<div class="wrap mls-custom-admin-style">
			<h1><?php echo esc_html(get_admin_page_title()); ?></h1>
				<p>Please activate your plugin license key to access all features.</p>
				<p>
    <a href="<?php echo esc_url(site_url()); ?>/wp-admin/admin.php?page=mls_plugin_license">click here</a> to activate the license.
</p>

			
		</div>
	<?php
	}		
	
}


// Hook to initialize plugin settings.
function mls_plugin_register_settings() {
    register_setting('mls_plugin_settings_group', 'mls_plugin_api_key');
    register_setting('mls_plugin_settings_group', 'mls_plugin_client_id'); // New Client ID field
    register_setting('mls_plugin_settings_group', 'mls_plugin_filter_id_sales'); // New Filter ID Sales field
    register_setting('mls_plugin_settings_group', 'mls_plugin_filter_id_short_rentals'); // New Filter ID Short Rentals field
    register_setting('mls_plugin_settings_group', 'mls_plugin_filter_id_long_rentals'); // New Filter ID Long Rentals field
    register_setting('mls_plugin_settings_group', 'mls_plugin_filter_id_features'); // New Filter ID Features field
	register_setting('mls_plugin_settings_group', 'mls_plugin_leadformtomail'); // New Filter ID Features field
	 register_setting('mls_plugin_settings_group', 'mls_plugin_property_types', 'mls_plugin_sanitize_property_types');
	
	// Add settings section and fields.
    add_settings_section('mls_plugin_section_id', '', null, 'mls_plugin');
	add_settings_field(
        'mls_plugin_property_types', 
        'Include Only Property Types on Search', 
        'mls_plugin_property_type_filter_callback', 
        'mls_plugin_settings_page', 
        'mls_plugin_section_id'
    );

    register_setting('mls_plugin_settings_group', 'mls_plugin_default_color');
    register_setting('mls_plugin_settings_group', 'mls_plugin_blue_color');
    register_setting('mls_plugin_settings_group', 'mls_plugin_green_color');
    register_setting('mls_plugin_settings_group', 'mls_plugin_black_color');
    register_setting('mls_plugin_settings_group', 'mls_plugin_white_color');
    register_setting('mls_plugin_settings_group', 'mls_plugin_border_color');
}

add_action('admin_init', 'mls_plugin_register_settings');

// Applying colors to the frontend.
function mls_plugin_apply_custom_colors() {
    $default_color = esc_attr(get_option('mls_plugin_default_color', '#5c727d'));
    $blue_color = esc_attr(get_option('mls_plugin_blue_color', '#0073e1'));
    $green_color = esc_attr(get_option('mls_plugin_green_color', '#69c17d'));
    $black_color = esc_attr(get_option('mls_plugin_black_color', '#222'));
    $white_color = esc_attr(get_option('mls_plugin_white_color', '#ffffff'));
    $border_color = esc_attr(get_option('mls_plugin_border_color', '#e7e7e7'));
	$banner_search_background_color = esc_attr(get_option('mls_plugin_banner_search_background_color'));
	$banner_search_text_color = esc_attr(get_option('mls_plugin_banner_search_text_color'));
	$banner_search_button_color = esc_attr(get_option('mls_plugin_banner_search_button_color'));
	$banner_search_buttonhoverbackground_color = esc_attr(get_option('mls_plugin_banner_search_buttonhoverbackground_color'));
	$banner_search_buttonbackground_color = esc_attr(get_option('mls_plugin_banner_search_buttonbackground_color'));
    ?>
    <style>
    :root {
        --mlsDefault-color: <?php echo esc_attr($default_color); ?>;
        --mlsSecondary-color: <?php echo esc_attr($blue_color); ?>;
        --mlsTertiary-color: <?php echo esc_attr($green_color); ?>;
        --mlsBlack-color: <?php echo esc_attr($black_color); ?>;
        --mlsWhite-color: <?php echo esc_attr($white_color); ?>;
        --mlsBorder-color: <?php echo esc_attr($border_color); ?>;
		--mlsbannersearchbackground-color: <?php echo esc_attr($banner_search_background_color); ?>;
		--mlsbannersearchbuttonbackground-color: <?php echo esc_attr($banner_search_buttonbackground_color); ?>;
		--mlsbannersearch-color: <?php echo esc_attr($banner_search_text_color); ?>;
--mlsbannersearchbutton-color: <?php echo esc_attr($banner_search_button_color); ?>;
--mlsbannersearchbuttonhoverbackground-color: <?php echo esc_attr($banner_search_buttonhoverbackground_color); ?>;
    }
</style>
    <?php
}
add_action('wp_head', 'mls_plugin_apply_custom_colors');

// Plugin Setting Field Validation

function mls_plugin_sanitize_settings($input) {
    // Sanitize each field
    $input['mls_plugin_api_key'] = sanitize_text_field($input['mls_plugin_api_key']);
    $input['mls_plugin_client_id'] = sanitize_text_field($input['mls_plugin_client_id']);
    $input['mls_plugin_filter_id_sales'] = sanitize_text_field($input['mls_plugin_filter_id_sales']);
    $input['mls_plugin_filter_id_short_rentals'] = sanitize_text_field($input['mls_plugin_filter_id_short_rentals']);
    $input['mls_plugin_filter_id_long_rentals'] = sanitize_text_field($input['mls_plugin_filter_id_long_rentals']);
    $input['mls_plugin_filter_id_features'] = sanitize_text_field($input['mls_plugin_filter_id_features']);
	$input['mls_plugin_leadformtomail'] = sanitize_text_field($input['mls_plugin_leadformtomail']);
	 if (isset($input['mls_plugin_property_types']) && is_array($input['mls_plugin_property_types'])) {
        $input['mls_plugin_property_types'] = array_map('sanitize_text_field', $input['mls_plugin_property_types']);
    }
    
    return $input;
}

add_filter('pre_update_option_mls_plugin_settings_group', 'mls_plugin_sanitize_settings');

// Sanitize the property types field.
// function mls_plugin_sanitize_property_types($input) {
//     if (is_array($input)) {
//         return array_map('sanitize_text_field', $input);
//     }
//     return sanitize_text_field($input);
// }




// Callback for the API key field.
function mls_plugin_api_key_callback() {
    $api_key = get_option('mls_plugin_api_key');
    echo '<input type="text" name="mls_plugin_api_key" value="' . esc_attr($api_key) . '" />';
}

// Function to create a single page
function create_mls_page($pageid, $title, $slug, $shortcode) {
    $page = get_page_by_path($slug);
    
    if (!$page) {
        $page_id = wp_insert_post(
            array(
                'import_id'    => $pageid,
                'post_title'    => $title,
                'post_content'  => $shortcode,
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_name'     => $slug
            )
        );
        return $page_id;
    }
    
    return $page->ID;
}

function create_mls_pages() {
    $pages = array(
        'property-list' => array(
            'title' => 'Property List',
            'shortcode' => '[mls_property_list]',
            'import_id' => '7864',
            'label' => 'MLS Listing Page'
        ),
        'property-detail' => array(
            'title' => 'Property Detail',
            'shortcode' => '[mls_property_detail]',
            'import_id' => '7865',
            'label' => 'MLS Detail Page'
        ),
        'property-search-result' => array(
            'title' => 'Property Search Result',
            'shortcode' => '[mls_search_results]',
            'import_id' => '7866',
            'label' => 'MLS Search Results Page'
        )
    );

    $created_pages = array();

    foreach ($pages as $slug => $page_data) {
        $page_id = create_mls_page($page_data['import_id'], $page_data['title'], $slug, $page_data['shortcode']);
        $created_pages[$slug] = array('id' => $page_id, 'label' => $page_data['label']);
    }

    // Store page IDs and their labels in options
    update_option('mls_plugin_page_ids', $created_pages);

    return $created_pages;
}

function mls_highlight_admin_pages($title, $post_id) {
    // Get the stored page IDs and labels from the options table
    $mls_pages = get_option('mls_plugin_page_ids');

    // Check if the current post ID matches one of the created pages
    if (!is_admin() || empty($mls_pages)) {
        return $title; // Return the title unmodified if not in admin or no pages are stored
    }

    foreach ($mls_pages as $slug => $page_data) {
        if ($post_id == $page_data['id']) {
            // Append the custom label to the title
            return $title . ' (' . esc_html($page_data['label']) . ')';
        }
    }

    return $title; // Return the unmodified title if no match is found
}
add_filter('the_title', 'mls_highlight_admin_pages', 10, 2);



?>