<?php
function my_plugin_register_settings() {
    register_setting('mls_plugin_options_group', 'mls_plugin_license_key');
}
add_action('admin_init', 'my_plugin_register_settings');
// Add submenu for license.
function mls_plugin_add_license_submenu() {
    add_submenu_page(
        'mls_plugin_settings',    // Parent slug (the main menu slug)
        'MLS Plugin License', // Page title
        'License',          // Menu title
        'manage_options',         // Capability required
        'mls_plugin_license', // Menu slug for the submenu
        'mls_plugin_license_page' // Function to display the page content
    );
}

add_action('admin_menu', 'mls_plugin_add_license_submenu');


function mls_plugin_license_page() {
	$license_key = get_option('mls_plugin_license_key');
    ?>
    <div class="wrap licence-style">
        <h1><?php esc_attr_e('Plugin Settings', 'mls-plugin'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('mls_plugin_options_group');
            do_settings_sections('mls_plugin_options_group');
            ?>
            <table class="form-table easySel-style">
                <tr valign="top">
                    <th scope="row"><?php esc_attr_e('License Key', 'mls-plugin'); ?></th>
                    <td><input type="text" name="mls_plugin_license_key" value="<?php echo esc_attr(get_option('mls_plugin_license_key')); ?>" /> <?php if (mls_plugin_is_license_valid()) { ?><p style="color:#00a32a;">
						Valid.
						</p><?php }elseif($license_key && !mls_plugin_is_license_valid()){ ?><p style="color:#d63638;">
						Invalid.
						</p><?php } ?>
					</td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
		 <?php if ($license_key) : ?>
            <form method="post">
                <input type="hidden" name="mls_plugin_deactivate_license" value="1" />
                <?php submit_button('Deactivate License', 'secondary'); ?>
            </form>
        <?php endif; ?>
    </div>
    <?php
}

// Handle the license deactivation request.
add_action('admin_init', 'mls_plugin_handle_license_deactivation');
function mls_plugin_handle_license_deactivation() {
    if (isset($_POST['mls_plugin_deactivate_license']) && $_POST['mls_plugin_deactivate_license'] == '1') {
        delete_option('mls_plugin_license_key');
        add_action('admin_notices', 'mls_plugin_license_deactivated_notice');
    }
}

// Show an admin notice when the license is deactivated.
function mls_plugin_license_deactivated_notice() {
    ?>
    <div class="notice notice-success">
        <p>License key has been deactivated successfully.</p>
    </div>
    <?php
}