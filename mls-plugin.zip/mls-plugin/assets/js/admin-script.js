jQuery(document).ready(function($){
        var mediaUploader;

        // Open media library on button click
        $('#mls_plugin_leadformmailheaderlogo_button').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media({
                title: 'Select Header Logo',
                button: {
                    text: 'Use this logo'
                },
                multiple: false
            });

            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#mls_plugin_leadformmailheaderlogo').val(attachment.url);
                $('#mls_plugin_leadformmailheaderlogo_preview').attr('src', attachment.url).show();
                $('#mls_plugin_leadformmailheaderlogo_remove').show();
            });

            mediaUploader.open();
        });

        // Remove image button functionality
        $('#mls_plugin_leadformmailheaderlogo_remove').click(function(e) {
            e.preventDefault();
            $('#mls_plugin_leadformmailheaderlogo').val('');
            $('#mls_plugin_leadformmailheaderlogo_preview').hide();
            $(this).hide();
        });
    });

/**Lead form submission popup**/
jQuery(document).ready(function($) {
    const modal = $('#mls-lead-details-modal');
    const modalBody = $('#mls-lead-details-body');

    // Show modal and load data
    $('.mls-view-details').on('click', function(e) {
        e.preventDefault();
        const leadId = $(this).data('lead-id');

        // Fetch data based on lead ID
        const leadDetails = leadsData[leadId];
        if (leadDetails) {
            modalBody.html(`
                <p><strong>Property ID:</strong> ${leadDetails.referenceid}</p>
                <p><strong>Name:</strong> ${leadDetails.user_name}</p>
                <p><strong>Email:</strong> ${leadDetails.email}</p>
                <p><strong>Phone:</strong> ${leadDetails.phone}</p>
                <p><strong>Schedule Time:</strong> ${leadDetails.lead_time}</p>
                <p><strong>Schedule Date:</strong> ${leadDetails.scheduledate}</p>
                <p><strong>Tour Type:</strong> ${leadDetails.personvideo}</p>
                <p><strong>Buyer/Seller:</strong> ${leadDetails.buyerseller}</p>
                <p><strong>Date Submitted:</strong> ${leadDetails.date_submitted}</p>
				<p><strong>Comments:</strong> ${leadDetails.comments}</p>
            `);

            modal.show();
        }
    });

    // Close modal
    $('.mls-close-modal').on('click', function() {
        modal.hide();
    });
});

/*Qualified Leads Ajax*/
jQuery(document).ready(function($) {
    $('.mls-toggle-qualified').on('click', function(e) {
        e.preventDefault();
        
        var leadId = $(this).data('lead-id');
        var qualified = $(this).data('qualified');
        var icon = $(this).find('span');
        var row = $(this).closest('.mls-qualified-lead'); // Get the current table row

        // Send AJAX request to toggle qualified status
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'mls_toggle_lead_status',
                lead_id: leadId,
                qualified: qualified,
            },
            success: function(response) {
                if (response.success) {
                    var newStatus = response.data.new_status;
                    // Update the star icon based on the new status
                    if (newStatus) {
                        icon.removeClass('dashicons-star-empty').addClass('dashicons-star-filled');
                    } else {
                        icon.removeClass('dashicons-star-filled').addClass('dashicons-star-empty');
                        // Remove row if in the "Qualified Leads" table
                        row.remove();
                    }
                    // Update the qualified data attribute
                    icon.closest('.mls-toggle-qualified').data('qualified', newStatus);
                }
            }
        });
    });
});



jQuery(document).ready(function($){
 $("#mls_property_types").easySelect({
     buttons: true, // 
     search: true,
     placeholder: 'Type',
     placeholderColor: '',
     selectColor: '#524781',
     itemTitle: 'Car selected',
     showEachItem: true,
     width: '100%',
     dropdownMaxHeight: '450px',
 })
 $("#mls_avail_time").easySelect({
     buttons: true, // 
     search: true,
     placeholder: 'Type',
     placeholderColor: '',
     selectColor: '#524781',
     itemTitle: 'Car selected',
     showEachItem: true,
     width: '100%',
     dropdownMaxHeight: '450px',
 })
});